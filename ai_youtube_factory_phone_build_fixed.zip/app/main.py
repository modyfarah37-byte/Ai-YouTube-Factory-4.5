import argparse
from apscheduler.schedulers.blocking import BlockingScheduler
from .config import load_config
from .db import init_db
from .pipeline import run_one

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--once", action="store_true")
    ap.add_argument("--topic", default="")
    ap.add_argument("--no-upload", action="store_true")
    args = ap.parse_args()
    init_db()
    cfg = load_config()

    if args.once:
        print(run_one(args.topic or None, not args.no_upload))
        return

    scheduler = BlockingScheduler(timezone="Africa/Cairo")
    for h in cfg["schedule_hours"][:cfg["videos_per_day"]]:
        hh, mm = map(int, h.split(":"))
        scheduler.add_job(lambda: run_one(), "cron", hour=hh, minute=mm,
                          id=f"job_{hh}_{mm}", replace_existing=True)
    print("AI YouTube Factory is running.")
    scheduler.start()

if __name__ == "__main__":
    main()
