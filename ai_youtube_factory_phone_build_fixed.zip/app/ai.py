import base64, json
from pathlib import Path
from openai import OpenAI
from .config import OPENAI_API_KEY, TEXT_MODEL, IMAGE_MODEL, TTS_MODEL, TTS_VOICE

if not OPENAI_API_KEY:
    raise RuntimeError("OPENAI_API_KEY is missing in .env")

client = OpenAI(api_key=OPENAI_API_KEY)

def ask_json(prompt):
    r = client.responses.create(model=TEXT_MODEL, input=prompt)
    raw = r.output_text.strip()
    if raw.startswith("```"):
        raw = raw.split("\n", 1)[1].rsplit("```", 1)[0]
    return json.loads(raw)

def choose_topic(cfg, recent):
    prompt = f"""أنت مدير قناة يوتيوب.
المجال: {cfg['niche']}
اللغة: {cfg['language']}
المدة: {cfg['duration_seconds']} ثانية.
اختر موضوعًا أصليًا جديدًا، ولا تكرر هذه المواضيع:
{chr(10).join('- '+x for x in recent)}
أرجع JSON فقط: {{"topic":"..."}}"""
    return ask_json(prompt)["topic"]

def make_content(topic, cfg):
    n = cfg["duration_seconds"]
    prompt = f"""أنشئ محتوى YouTube أصليًا.
المجال: {cfg['niche']}
اللغة: {cfg['language']}
الموضوع: {topic}
المدة: {n} ثانية.
لا تختلق أرقامًا أو مصادر. العنوان جذاب بدون تضليل.
أرجع JSON فقط:
{{"title":"...","description":"...","tags":["..."],"script":"...",
"scenes":[{{"visual_prompt":"وصف بصري بدون أي كتابة داخل الصورة","duration":7}}]}}
يجب أن يكون مجموع مدد المشاهد قريبًا من {n} ثانية."""
    return ask_json(prompt)

def generate_image(prompt, out_path):
    result = client.images.generate(
        model=IMAGE_MODEL, prompt=prompt,
        size="1024x1024", quality="medium"
    )
    Path(out_path).write_bytes(base64.b64decode(result.data[0].b64_json))
    return out_path

def generate_tts(text, out_path, voice=None):
    with client.audio.speech.with_streaming_response.create(
        model=TTS_MODEL, voice=voice or TTS_VOICE,
        input=text, response_format="mp3"
    ) as r:
        r.stream_to_file(out_path)
    return out_path
