package com.aifactory.youtube;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    LinearLayout root, body;
    EditText server, token;
    TextView status;

    int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    TextView label(String s) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(16); t.setTextColor(Color.WHITE);
        t.setPadding(dp(4), dp(8), dp(4), dp(8));
        return t;
    }

    Button btn(String s) {
        Button b = new Button(this); b.setText(s); return b;
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        build();
    }

    void build() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(18));
        root.setBackgroundColor(Color.rgb(15,18,24));

        TextView title = label("AI YouTube Factory");
        title.setTextSize(25); title.setTextColor(Color.WHITE);
        root.addView(title);

        TextView sub = label("لوحة تحكم إنتاج ونشر الفيديوهات تلقائيًا");
        sub.setTextColor(Color.LTGRAY); root.addView(sub);

        server = new EditText(this);
        server.setHint("رابط السيرفر مثل https://your-server.com");
        server.setSingleLine(true); server.setText("http://10.0.2.2:8000");
        server.setTextColor(Color.WHITE); server.setHintTextColor(Color.GRAY);
        root.addView(server);

        token = new EditText(this);
        token.setHint("API Token");
        token.setSingleLine(true); token.setInputType(0x81);
        token.setTextColor(Color.WHITE); token.setHintTextColor(Color.GRAY);
        root.addView(token);

        Button save = btn("حفظ الإعدادات");
        root.addView(save);

        LinearLayout row = new LinearLayout(this);
        Button start = btn("▶ تشغيل فيديو الآن");
        Button refresh = btn("↻ تحديث");
        row.addView(start, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(refresh, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(row);

        status = label("الحالة: لم يتم الاتصال");
        status.setTextColor(Color.YELLOW);
        root.addView(status);

        body = new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL);
        root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));

        save.setOnClickListener(v -> savePrefs());
        start.setOnClickListener(v -> post("/jobs", "{}"));
        refresh.setOnClickListener(v -> get("/status"));
        loadPrefs();
        setContentView(root);
        get("/status");
    }

    void savePrefs() {
        getSharedPreferences("cfg",0).edit()
            .putString("server", server.getText().toString().trim())
            .putString("token", token.getText().toString().trim()).apply();
        status.setText("تم حفظ الإعدادات");
    }

    void loadPrefs() {
        android.content.SharedPreferences p = getSharedPreferences("cfg",0);
        server.setText(p.getString("server", server.getText().toString()));
        token.setText(p.getString("token",""));
    }

    String base() { return server.getText().toString().replaceAll("/$",""); }

    void get(String path) {
        request("GET", path, "");
    }

    void post(String path, String body) {
        request("POST", path, body);
    }

    void request(String method, String path, String body) {
        status.setText("جارِ الاتصال...");
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                URL u = new URL(base()+path);
                HttpURLConnection c = (HttpURLConnection)u.openConnection();
                c.setRequestMethod(method);
                c.setConnectTimeout(10000); c.setReadTimeout(20000);
                c.setRequestProperty("Authorization","Bearer "+token.getText().toString().trim());
                c.setRequestProperty("Content-Type","application/json");
                if (method.equals("POST")) {
                    c.setDoOutput(true);
                    c.getOutputStream().write(body.getBytes("UTF-8"));
                }
                int code = c.getResponseCode();
                InputStream is = code >= 400 ? c.getErrorStream() : c.getInputStream();
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                StringBuilder out = new StringBuilder(); String line;
                while ((line=br.readLine())!=null) out.append(line);
                final String result = out.toString();
                runOnUiThread(() -> status.setText("HTTP "+code+"  "+result));
            } catch(Exception e) {
                runOnUiThread(() -> status.setText("خطأ اتصال: "+e.getMessage()));
            }
        });
    }
}
